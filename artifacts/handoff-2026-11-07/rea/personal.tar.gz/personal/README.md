# REA — Creazione personale

REA CLI6.8.0 usato sull’implementazione di Excalidraw e sul comportamento reale del consumer Ardesia. [Dossier](personal-authoring-dossier.md), manifest Git/SHA256, sorgenti selezionati, licenza MIT, raw e stderr conservati.

Donor Excalidraw@701b901a0f1ba3d0b390d9cdf63d112e25abac4b: cinque file,2958 nodi AST,0 parse/integrity error,514 unknown, coverage unknown. Sei file donor (cinque sorgenti e la licenza) e due fonti legacy verificati byte per byte: otto blob complessivi. ADAPT: azioni dipendenti dalla risorsa, stato fresco, contenuto/stato/assets separati. REPLACE: view mode come sicurezza, storage globale, fallback silenzioso. Nessun codice donor copiato e nessuna prova runtime donor attestata.

Consumer: due account student sintetici, Chrome sul Mac1536×1024 e viewport mobile412×915. Ogni scenario esegue login, Home, nuova lezione, nuovo tipo con controllo, salvataggio, ritorno alla Home, riapertura, modifica struttura in nuova versione e ritorno. Azioni reali attraverso HTTP/Core/PostgreSQL, con screenshot, accessibilità e osservazioni console/network per passo. La copia offline, i conflitti, l’isolamento server e MCP sono verificati nelle suite separate.

Il sorgente è associato separatamente tramite build-info e SHA256 degli asset effettivamente osservati e serviti, in runtime-source.json. REA non certifica identità del sorgente, causalità del backend o prestazioni Pencil. Viewport mobile non è un dispositivo iPad e non prova Safari. Le limitazioni native di REA restano nei raw. [Verifiche e review](../../verifiche/personal/README.md).

![Home personale](desktop-final-home.png)

[Home mobile](mobile-final-home.png) · [Tipo inventato](desktop-version-saved.png)
