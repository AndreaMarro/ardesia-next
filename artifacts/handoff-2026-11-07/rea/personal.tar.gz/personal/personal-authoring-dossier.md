# Spazio personale universale — ricerca bounded

Stato: ricerca read-only completata; nessuna implementazione o prova del consumer. Solo artefatti in work/rea-personal. Il mandato diretto corrente riportato dal coordinatore consente creazione personale anche ad account student e prevale sui limiti storici teacher-only. Non amplia automaticamente publishing, assegnazione didattica, lettura degli elaborati altrui o accessi commerciali.

## Requisiti precisi

Legacy AndreaMarro/ardesia @ 5cfbdcb055ba3ba136f97fb56e997f06e6cf3605, docs/product/ARDESIA_specifiche_integrali_ricostruite_2026-10-28.md:

- :42–43: identità ≠ ruolo ≠ entitlement ≠ ownership ≠ visibilità; creatività locale indipendente dal ruolo docente.
- :57–68: una identità, ruoli contestuali, Study/Teach/Create; cambio modalità senza clonare Lesson/istanze; «un allievo può creare un plugin locale». Ingresso creativo dalla lavagna e ingresso didattico dalla prossima azione sono compatibili.
- :129–141: le capability limitano ogni operazione; figlio visuale/composizione non elevano permessi. Configure→Compose→No-code→Code usa lo stesso formato; marketplace non è prerequisito dell'editor.
- :381–383: quaderno personale isolato; docente vede il consegnato autorizzato, non la bozza privata; peer esclusi; revoca efficace anche con URL/cache persistenti.
- :750 CORE-007: cambio modalità mantiene medesima Lesson/istanze.
- :756–760 ROLE-001/002/003/004/005: ruoli separati dai piani, «Nessun gate teacher-only sul creator locale», publishing/monetizzazione con eligibility distinta, Knowledge privato, grant/revoke scoped.
- :812 GROUP-002: stato personale separato dal condiviso.
- :838–842 NFR-PRIV-001/002/003/004 e NFR-REL-001: ambizione storica senza account, export/delete comprensibili, nessun processing remoto implicito, privacy rispetto ad analytics e riapertura senza perdita. Il golden path anonimo è più ampio dell'incremento richiesto, che riguarda account student; non viene dichiarato implementato.

Corroborazione: docs/ardesia-v4/specs/02_PERSONE_CORSI_E_GESTIONALE.md:4–13,37. User/Membership e commerciale/didattico distinti; learner_private, submitted_to_assigned_tutor, cohort_shared, teacher_private; un tutor non eredita tutta la storia. Fonte e revisioni restano identiche passando fra lavagna, corso e studio.

Hash completi e Git blob SHA sono in legacy-manifest.json. Copie byte-identiche preservate; lettura selettiva, non ricostruzione integrale. Nessuna licenza OSS generale del legacy dedotta.

Il programma2026 è stato consultato soltanto attraverso il precedente dossier docs/sources/creator-studio-2026-11-07.md, che registra versione6novembre e SHA256 2de0ad702c65eccb43cc9b156fc9cc44fcc45902cf934d8873d34d2404fcbb9f. Non ho recuperato/riletto l'originale né le chat in questo incarico. L'autorità dell'incremento viene dal mandato corrente, non da un'inferenza su quel file.

## Superfici Next osservate prima/durante l'avvio del lavoro root

Sono indizi per l'integrazione, non review del candidato finale. current-surface-evidence.json conserva excerpt, SHA256 del file e timestamp. Git HEAD osservato f7adf5db02913e25fbab0b1da071f650b4f78676; il parent denomina la base final097a, che non tratto come commit Git. Working tree modificabile dal root: nessuna equivalenza fra questi excerpt e sorgente finale.

- packages/core/src/index.ts:112,326,375,540–550: owner/edit/installazioni/elenco documenti gated da teacher.
- packages/core/src/courses.ts:13,32,124–140: authoring e proiezione corso confluiscono con ruolo docente; assign/revoke devono essere trattati come capacità separate. CourseEvent già conserva actorRole reale e validateCourseHistory riproduce comandi/revisioni/receipt.
- packages/server/src/store.ts:61–68: owner_bindings risolto solo dal ramo teacher, student ammesso via assignment; :85 blocco create/import; :169–174 lista own oppure assigned secondo ruolo. Spostare l'autorità verso ownership senza fingere role:teacher.
- packages/remote-client/src/index.ts:116–143: parser rigetta documenti/installazioni/eventi/course privati per student; :669 gate ownedDocument. Rimuovere solo il blocco UI lascerebbe risposte invalide.
- packages/remote-client/src/offline.ts:6,31–38,103,126: formato/parse/gate owner copy letteralmente teacher; account-switch e sign-out devono continuare a isolare copie/queue.
- packages/mcp-core/src/adapter.ts:41,53 e cli.ts:26: student con owned documents/events viene rifiutato, writable richiede teacher. Read-write esplicito e workspace scope restano necessari anche per owner student.
- apps/web/src/RemoteWorkspace.tsx:132–154: creazione spazio e App/LearnerSpace dipendono dal ruolo; lo studente può essere proprietario di uno spazio e assegnatario in un altro.
- recordings Core/server/client hanno gate analoghi. Estenderli soltanto se il perimetro del nuovo percorso li include; non dichiararli coperti da una prova solo Creator.

## Donor unico e REA concreto

Excalidraw/excalidraw, repository ID 231283452, commit **701b901a0f1ba3d0b390d9cdf63d112e25abac4b**, data 2026-11-05T17:10:20Z. Root LICENSE MIT, copyright 2020 Excalidraw. Albero completo 1471 entry, non troncato; unica altra LICENSE sotto packages/laser-pointer, fuori dal campione. Sei blob sorgente/licenza verificati byte per byte con Git blob SHA e SHA256 in donor-manifest.json. Nessun codice donor copiato nel prodotto.

Campione:

| Percorso | Evidenza sorgente | Decisione |
| --- | --- | --- |
| packages/excalidraw/actions/types.ts:17–32,217–223 | Origine azione ui/keyboard/contextMenu/api; risultato con elementi/stato/file e captureUpdate; viewMode/navigation sono opt-in per singola azione. | ADAPT classificazione delle azioni lettura/navigazione/modifica. Non riusare come ACL. |
| packages/excalidraw/actions/manager.tsx:92–147,151–177,195–220,237–244 | Keyboard filtra interazione e viewMode. executeAction permette API host anche quando editor non interattivo; predicate separato in isActionEnabled. updateData rilegge stato corrente per evitare closure obsolete. | ADAPT stato corrente al comando e controllo per azione. REPLACE per sicurezza con verifica Core/server indipendente dalla provenienza UI/API/MCP. Il file non costituisce un modello utenti/ownership. |
| packages/excalidraw/actions/actionToggleViewMode.tsx:18–32 | Vista lettura = appState; azione toggle visibile solo se prop viewModeEnabled non imposta dall'host e interazione abilitata. | ADAPT modalità locale e vincolo host; mai interpretare switch view/edit come elevazione di diritti. |
| excalidraw-app/data/LocalData.ts:73–107,124–171,211–232 | Elementi/stato in localStorage, file in IndexedDB; debounce e flush; pausa per collaborazione/document.hidden; errori quota e mappe file salvati/falliti. | ADAPT distinzione stato editor/contenuto/assets e feedback di persistenza. REPLACE storage globale con Core/Remote Client già esistenti e scope account/workspace/document. Il salvataggio fra supporti non è atomico nel campione. |
| excalidraw-app/data/localStorage.ts:37–74 | Riapre elementi e stato; JSON invalido loggato e fallback a vuoto/null. | ADAPT riapertura dalle stesse identità. REPLACE fallback silenzioso: dati corrotti/pendenti devono restare recuperabili, senza vuoto sovrascritto come successo. |

REA CLI 6.8.0 con Node24.22.1 realmente eseguito su cinque TS/TSX inerti, senza eseguire applicazione, build, test, account o collaborazione.
Comando e argv completi: run.json. Raw: rea-personal-authoring.json e stderr.
Evidence **ev_f3c99c64cb6cdb6fbc24ec154896abf52aac612ba9ad025c659dc18fcda73b72**.
Raw SHA256 **cd6f5b0349d814e525691de75398f7ab4d7bd063fe5317bd14dd67923ab2a6c9**.
Root artifact **385cd5a49801bca8677090e5c94c9b64fa8b840e89f659402f662d15658127b9**.
Esito0; 5 file,2958 nodi AST,108 finding,0 parse failure,0 integrity contradiction. Copertura semantica dichiarata **unknown**, non troncata,514 unknown:170 unknown-value,131 dynamic-call,205 ambiguous-target,8 dynamic-property. Nessun cap raggiunto. Import esterni non inclusi; REA non prova assenza di effetti, correttezza runtime o autorizzazioni. rea-summary.json conserva funzioni/call-site/range/ID; i trasferimenti sopra sono interpretazione della lettura diretta corroborata dall'AST.

Riuso di ricerca precedente: il dossier Creator registra Excalidraw package0.18.1, MIT, evidence ev_b86a1ea5ed02b696bce4107340f36f049ac90bdbadbf612d9a663951f4ab3a7c per slice viewMode/openDialog/tool/selection. Quella slice e il runtime pubblico 2026-11-04T19:55:10Z-3c916c5 sono artefatti distinti dal commit qui analizzato; non trasferisco PASS o equivalenza. prior-source-index.json conserva hash dei soli due reperti riletti.

## Contratto di trasferimento consigliato

Percorso: account student senza assegnazioni → crea proprio spazio → lavagna/nota/formula → Creator e salvataggio definizione/istanza → corso privato con lezione/revisione propria → chiudi/riapri/relogin e riprendi stessi ID, versioni e contenuti. Nessuna assegnazione docente sintetica, promozione dell'account o clone implicito per entrare nell'editor.

Matrice da implementare nello stesso sistema:

| Risorsa/operazione | Owner student o teacher | Assegnatario non owner | Estraneo |
| --- | --- | --- | --- |
| Creare proprio spazio/documento e oggetti | Consentito secondo mandato e limiti esistenti | Crea nel proprio spazio, non in quello altrui | Nessun accesso al materiale |
| Modificare/riaprire/esportare fonte personale | Ownership, revisioni e provenance verificate | Nessuna modifica del documento docente | Negato senza rivelare esistenza |
| Creator/programmi privati | Stesso Host, consenso/versione e quote; nessun nuovo privilegio | Solo interazioni concesse sullo stato personale | Negato |
| Corso privato/versione personale | Authoring e riferimenti esatti propri | Legge solo edizione autorizzata | Negato |
| Assegnare a terzi/pubblicare/monetizzare | Capacità distinta, non concessa dal semplice essere owner | Nessun diritto implicito | Negato |
| Lavoro personale di uno studente assegnato | Il docente non ottiene il privato; serve condivisione valida | Solo il proprio lavoro | Negato |

Il nuovo owner student mantiene actor.role='student' nelle ricevute e nella storia; ownership autenticata non si ottiene dal payload browser. Il percorso personale non muta la semantica dei grant in un altro spazio. Un corso privato può essere salvato/versionato senza diventare pubblicato o assegnato; distinguere la versione editoriale dalla distribuzione.

Riapertura/export/import: autorizzare prima di leggere/restituire ricevute; preservare ID e revisioni esatte, immutabilità dell'owner e conflitti espliciti. Compatibilità del formato offline e binding storico importato va definita, non risolta riscrivendo i ruoli storici o allargando l'accesso ai contenuti teacher. Cache, pending e ultime selezioni vanno isolate da account/workspace; logout/revoca chiudono accesso successivo senza cancellare arbitrariamente lavoro personale salvato.

## Prove richieste al consumer (non eseguite qui)

1. Student senza corsi assegnati crea spazio, nota e oggetto Creator, modifica parametri, salva corso personale collegato alla revisione lezione; reload/cold-open conserva tutto.
2. Stesso student passa fra proprio spazio e workspace docente assegnato; può modificare il primo e solo il proprio lavoro autorizzato nel secondo. Nessuna mutazione della fonte docente.
3. Altro student/teacher indovina ID privato o cambia ownerId/actorId/role: lettura, scrittura, ricerca, export, MCP negati; non basta nascondere pulsanti.
4. Student owner usa read-write MCP esplicito scoped; la stessa richiesta in workspace altrui o dopo revoca non rigioca una vecchia ricevuta come nuovo grant.
5. Doppio submit/retry e revisione stale non creano copie; import compatibile preserva provenance; snapshot corrotto non si trasforma in spazio vuoto confermato.
6. Account-switch/logout/riapertura offline non mostra documenti, cache o pending dell'altra persona. Cambio modalità non duplica oggetti.
7. Grant didattico, consenso modulo e condivisione elaborato restano distinti; revoca nell'aula non rimuove lo spazio personale dello studente.
8. Programmi Creator conservano isolamento e quote anche per owner student; creazione privata non pubblica nel catalogo, non concede rete/native capability né attiva servizi.

Limiti ed errori: nessun consumer/test runtime eseguito; prodotto e stato condiviso solo letti. Primo rg e lettura product-map hanno output troncato, poi seguiti da estratti mirati. Tentativo di leggere server/src/service.ts e core/src/plugins.ts ha restituito path assenti: inventario corretto con store.ts; non sono letture riuscite. Nessuna nuova lettura chat, installazione, account, messaggio esterno, remoto Git, servizio o scheduler.

