import fs from 'node:fs';
import {createRequire} from 'node:module';
import {browserScenarioActionSchema,browserScenarioCaptureSchema,browserScenarioBrowserSchema} from '../tooling/node_modules/rea-agents/dist/domain/browserScenarioValues.js';
import {browserScenarioInputSchema} from '../tooling/node_modules/rea-agents/dist/domain/browserScenario.js';
const require=createRequire(new URL('../tooling/node_modules/rea-agents/package.json',import.meta.url));
const {z}=require('zod');
let actionJSON;
for(const [name,schema] of [['action',browserScenarioActionSchema],['capture',browserScenarioCaptureSchema],['browser',browserScenarioBrowserSchema],['input',browserScenarioInputSchema]]){
  const value=z.toJSONSchema(schema,{io:'input',unrepresentable:'any'});
  if(name==='action') actionJSON=value;
  fs.writeFileSync(new URL('capture-browser-'+name+'-schema.json',import.meta.url),JSON.stringify(value,null,2)+'\n');
}
const actions=(actionJSON.oneOf??actionJSON.anyOf).flatMap(arm=>{
  const value=arm.properties.action;
  return 'const' in value?[value.const]:value.enum;
});
const cases=[
  {action:'set_input_files',step_id:'upload',locator:{kind:'css',selector:'input[type=file]'},files:['/tmp/synthetic.pdf']},
  {action:'setInputFiles',step_id:'upload',locator:{kind:'css',selector:'input[type=file]'},files:['/tmp/synthetic.pdf']},
  {action:'upload',step_id:'upload',locator:{kind:'css',selector:'input[type=file]'},path:'/tmp/synthetic.pdf'}
];
const result={
  tool:'REA6.8.0 installed contract only',noBrowserOpened:true,actionKinds:actions,
  attempts:cases.map(value=>{const r=browserScenarioActionSchema.safeParse(value);return {input:value,success:r.success,issues:r.success?[]:r.error.issues};}),
  downloadCaptureAccepted:browserScenarioCaptureSchema.safeParse({events:['downloads']}).success
};
fs.writeFileSync(new URL('capture-browser-validation.json',import.meta.url),JSON.stringify(result,null,2)+'\n');
process.stdout.write(JSON.stringify(result,null,2)+'\n');
