# REA6.8 capture-browser-scenario — upload e download

Verifica locale del contratto installato, senza aprire browser o eseguire una capture. Non è una prova del consumer.

**Upload da file locale: non supportato.** La discriminated union ammette soltanto goto, click, fill, press, select_option, check, uncheck, wait_for, request, wait_for_timeout. Il dispatcher inoltra fill a Playwright locator.fill, non a setInputFiles. Non esistono azione set_input_files/setInputFiles/upload, filechooser, evaluate o script utente nel contratto esaminato.

Prova concreta: browserScenarioActionSchema.safeParse ha rifiutato tutti e tre i nomi di azione upload con "Invalid discriminator value"; input e issue completi in capture-browser-validation.json. I path di esempio non sono stati aperti. request ammette una richiesta same-origin con JSON, non un file locale/multipart e non prova l'interazione nativa di import; non viene proposto come sostituto del file chooser.

**Download: tentativo osservabile, file non acquisito.** Configurare capture.events includendo "downloads" (validato nello schema). PlaywrightScenarioEvents.js:490–500 registra kind:"download-cancelled", suggested_filename e URL sanificati, poi chiama download.cancel() best-effort. La launch di PlaywrightScenarioBrowser.js:570 imposta acceptDownloads:false. L'evidence non attesta completamento, byte ricevuti, file salvato, hash dell'originale o successo di download. Anche in connect il listener attivo cancella il download osservato.

Frammento di configurazione supportato (da integrare nella richiesta completa del root):
```json
{
  "capture": {
    "after_each_step": ["screenshot", "dom", "accessibility"],
    "at_end": ["screenshot", "url"],
    "events": ["page-errors", "downloads"]
  }
}
```

**Attach CDP non mantiene una preview soltanto in memoria.** mode:"connect" è previsto con cdp_endpoint e target_id, ma PlaywrightScenarioSession.js:151 esegue comunque page.goto(start_url) durante apertura scenario. Un input file/preview preparato da E2E e non salvato potrebbe quindi andare perso. Il termine "tab preparata" non implica continuazione senza navigazione.

Ripartizione di prova consigliata, senza workaround:
1. E2E ordinario: file locale sintetico → preview → navigazione → scelta pagina → import persistente → riapertura → download effettivo e confronto SHA256.
2. REA: parte da materiale sintetico già persistito e riapribile, osserva navigazione/annotazione/riapertura e click Scarica; se compare download-cancelled lo riporta come tentativo intercettato.
3. Manifest unico lega fixture originale/hash e sorgente del consumer alle due prove distinte. Non attribuire a REA le azioni compiute da E2E.

Fonti installate precise (copie byte-identiche + hash in capture-browser-contract-manifest.json):
- dist/domain/browserScenarioValues.js:227–314 union azioni; :352–373 capture schema; :145–163 launch/connect.
- dist/domain/browserScenarioCaptureValues.js:105–115 eventi; :242–247 download-cancelled.
- dist/browser/PlaywrightScenarioActions.js:20–71 dispatcher.
- dist/browser/PlaywrightScenarioEvents.js:363–366 listener; :490–500 cancellazione.
- dist/browser/PlaywrightScenarioBrowser.js:554–586 launch.
- dist/browser/PlaywrightScenarioSession.js:149–156 navigazione iniziale.
- dist/browser/PlaywrightScenarioRequest.js:100–134 fetch dichiarativo; nessun upload filesystem.

CLI reale:
```text
work/tooling/node_modules/.bin/node work/tooling/node_modules/rea-agents/scripts/rea.mjs capture-browser-scenario --help
work/tooling/node_modules/.bin/node work/tooling/node_modules/rea-agents/scripts/rea.mjs capture-browser-scenario --schema
```
Il --schema CLI espone solo inputJson:string; il contratto completo è il modulo Zod installato. Sono state esportate schema input/action/capture/browser con z.toJSONSchema({io:"input",unrepresentable:"any"}). Queste rappresentazioni JSON non sostituiscono refinements/trasformazioni runtime: la prova dei discriminatori usa direttamente Zod safeParse. Lo script locale riproducibile è capture-browser-probe.mjs.

Limiti: nessuna capture live, click o download effettuato; nessuna patch REA/prodotto, installazione, servizio o login. Prima estrazione dei nomi azione contava solo enum e ometteva literal; corretta leggendo const/enum dal JSON Schema. Il primo risultato di validazione conteneva già l'elenco completo nei messaggi di rifiuto. Ricerca READ_ONLY completata, non consumer acceptance.
