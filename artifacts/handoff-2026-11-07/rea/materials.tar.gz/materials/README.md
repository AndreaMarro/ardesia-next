# REA — PDF, immagini e annotazioni

REA CLI6.8.0: [dossier](materials-dossier.md), [run statiche](runs.json), commit/licenze/hash e raw preservati. PDF.js6.5.438 Apache-2.0:11053 AST/2690unknown; supplemento navigazione+immagini2794 AST/630unknown. Copertura partial/unknown,0errori; nessun trapianto donor.

Consumer finale: due scenari da21passi completi su Chrome Mac e viewport mobile; apertura originali, proprietà, tentativo download, traslazione pagina, taccuino/lettura e riapertura. L’annotazione di fixture è stata creata tramite Core; REA la osserva e ne sposta la pagina, non la disegna. I tentativi precedenti conservano il login che apre automaticamente la lezione e il click bloccato sul canvas in modalità penna. Upload e tratti reali sono provati separatamente con Playwright.

REA non offre upload locale e annulla i download osservati: download-cancelled non è un byte salvato. [Contratto verificato](capture-browser-capabilities.md). [Associazione sorgente/HTTP](runtime-source.json): hash degli asset serviti e postcondizioni autorizzate, indipendenti da REA. Nessuna prova fisica iPad/Pencil o accettazione prodotto.

![Pagina nella lezione](runtime/desktop-original-ready.png)

[Prove e review](../../verifiche/materials/README.md).
