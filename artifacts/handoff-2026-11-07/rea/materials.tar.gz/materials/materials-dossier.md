# Materiali PDF e immagini — dossier di ricerca

Ricerca read-only; scritture solo in work/rea-materials. Nessun giudizio sul consumer, test prodotto, runtime donor, installazione, account, servizio o scheduler. Il root implementa e verifica.

## Indicazione implementabile

Usare **pdfjs-dist 6.5.438** come candidato renderer PDF, con worker e risorse distribuiti dalla stessa versione e serviti localmente. Conservare nel Core l'originale immutabile con hash SHA256, byte length, MIME verificato, owner/scope e revisione; canvas/thumbnail e layout sono proiezioni. Un URL blob o una data URL non è un originale durevole.

Il percorso API verificato nella release è:

```js
// Esempio di integrazione suggerito, non eseguito in questa ricerca.
GlobalWorkerOptions.workerSrc = workerUrl; // asset locale, stessa versione
const loadingTask = getDocument({ data: originalBytes.slice() });
const pdf = await loadingTask.promise;
const page = await pdf.getPage(pageNumber); // 1 .. pdf.numPages
const viewport = page.getViewport({ scale, rotation });
const renderTask = page.render({ canvas, viewport, transform });
await renderTask.promise;
```

Hash e persistenza dell'originale precedono il rendering: api.js:104–111 avverte che Uint8Array viene generalmente trasferita al worker, prendendone possesso. La copia evita di perdere il buffer che upload/hash/export devono ancora usare. api_utils.js:62–94 normalizza i dati e rifiuta Buffer Node nelle build generiche; usare Uint8Array.

In v6 api.js:1231–1241 raccomanda render({canvas,...}); canvasContext è compatibilità. GlobalWorkerOptions.workerSrc è esplicito; rendererSrc è un secondo worker opzionale e, se assente, il rendering ricade sul main thread, mentre parsing resta separato. Non dichiarare rendering interamente in worker solo perché pdf.worker.mjs è presente.

Controllo aggiuntivo sul pdfjs-dist6.5.438 installato dal root, letto senza modificarlo: isEvalSupported ha zero occorrenze nei tipi pubblici api.d.ts, build/pdf.mjs e build/pdf.worker.mjs; non è un'opzione del getDocument corrente. enableScripting è assente da DocumentInitParameters/getDocument ma compare nel bundle come parametro dell'AnnotationLayer: non usarlo nel loader come barriera. enableXfa è ancora tipizzato (api.d.ts:164) e attivo soltanto con src.enableXfa===true. Percorsi, conteggi e hash dei file realmente letti sono in pdfjs-flags-check.json; non è una prova runtime o dell'integrità dell'intero tarball.

CMap, font standard, wasm e profili ICC richiedono path locali corretti se necessari al corpus. Disabilitare fetch dal worker non rende automaticamente disponibili risorse mancanti. Niente CDN o upload documenti a servizi esterni necessario per i byte locali. L'esempio base non dimostra copertura font non latini, JPEG2000/JBIG2, scansioni o tutti i PDF.

## Provenienza e licenze

PDF.js: mozilla/pdf.js, repository ID1663468; release/tag **v6.5.438**, pubblicata 2026-11-01T18:15:43Z; tag risolto a commit immutabile **0a4153349dc473ba950fc17941c5ca7eda43c1de**. LICENSE e header dei file selezionati Apache-2.0. Metadata npm verificata: pdfjs-dist@6.5.438, Apache-2.0, engines Node >=22.13.0 || >=24; integrity dichiarata dal registry **sha512-vg8Pw1x+AFKy4AMDvhuWl5cOYV8d698UoEANoFFhc79hqXDnZQqnOXoxw3HG907WHOg1JYOvLhP756boddFxpA==**. Tarball/ZIP non scaricati né verificati qui: il parent deve bloccare la versione installata e conservare le notices distribuite, anche per risorse/dependency incluse. Metadata e digest pubblici degli ZIP sono preservati senza affermare verifica del binario.

Dieci blob sorgente/documentazione/licenza PDF.js scaricati via connettore GitHub e verificati byte per byte (Git blob SHA + SHA256). Percorsi esatti e URL in pdfjs-manifest.json:
src/display/api.js, api_utils.js, page_viewport.js, worker_options.js, display_utils.js; examples/learning/prevnext.html, helloworld64.html; README.md, package.json, LICENSE.

Supplemento immagini: Excalidraw/excalidraw @ **701b901a0f1ba3d0b390d9cdf63d112e25abac4b**, MIT. Soltanto packages/excalidraw/data/blob.ts, image.ts e LICENSE. Non si adotta il toolkit né i suoi import esterni; quelle dipendenze non sono analizzate o licenziate da questa ricerca. Hash/URL in supplement-manifest.json.

## Comportamenti e trasferimenti

| Evidenza sorgente | Trasferimento per Ardesia |
| --- | --- |
| PDF.js api.js:763–770: fingerprints non garantiti unici; :993–998 getData restituisce byte raw. | **REPLACE** fingerprint come identità: SHA256 dei byte originali, non fingerprint PDF, nome file o immagine raster. |
| page_viewport.js:54–153,183–216: matrice con viewBox, userUnit, rotazione e offset; convertToPdfPoint/convertToViewportPoint. | **ADAPT** coordinate sorgente stabili. Anchor = asset/revisione/hash/pagina + coordinate di pagina; layout lavagna, DPR e zoom separati. Un material object può cambiare pagina senza trasferire i tratti di pagina2 su pagina3. |
| api.js:3242–3277,3414–3425,3499–3519: cancel rigetta la promise; vietati render concorrenti sullo stesso canvas. | **ADAPT** ciclo cancel→settle→nuovo render, con generation token anche per getPage/load ritardati. Catch della cancellazione attesa; un errore vero resta visibile. |
| api.js:573–611: destroy interrompe richieste/worker e gestisce race del setup; :1854–1875 cleanup può restituire false se rendering attivo. | **ADAPT** teardown su cambio risorsa/account/unmount; non trattare cleanup come distruzione riuscita. Rilasciare URL temporanei e canvas derivati quando non servono. |
| examples/learning/prevnext.html:38–96: una render task, ultimo pageNumPending, HiDPI separato dal CSS; :102–119 limiti 1..numPages. | **ADAPT** navigazione seriale/latest requested e dimensioni coerenti. **REPLACE** esempio didattico incompleto per error/retry/unmount/revoca; il contatore non deve attestare una pagina riuscita prima del render. |
| api.js:154–167,258–271: maxImageSize default illimitato, canvasMaxAreaInBytes riguarda ridimensionamento immagini interne. | **ADAPT** budget espliciti e **aggiungere** cap del canvas finale width×height×DPR², numero render simultanei e bytes/page count. Non renderizzare tutte le pagine al massimo zoom per importare un PDF. |
| Excalidraw blob.ts:263–274 SHA1 con fallback random; :359–416 resize/ricodifica; :471–504 sniff magic con fallback MIME dichiarato. | **REPLACE** come integrità originale. Hash SHA256 obbligatorio verificato, originale intatto; eventuale resize è derivato distinto. Extension/MIME/magic non sostituiscono decoding, dimensioni e limiti. |
| Excalidraw blob.ts:34–81 e image.ts:51–74: PNG/SVG possono contenere un'intera scena esportata da ripristinare. | **REPLACE** import scena automatico nel flusso materiale: un'immagine viene inserita come risorsa, non interpreta metadata come comandi o sostituisce la lavagna. Import di pacchetti resta percorso distinto. |

I metodi viewport gestiscono rotazioni multiple di90 e crop/viewBox; non reinventare coordinate basandosi solo su width/height. Per immagini considerare dimensione/orientamento di decodifica (es. EXIF) e conservare originale distinto da orientamento/layout. PNG/JPEG/WebP sono un primo perimetro coerente col legacy; SVG richiede un trattamento esplicito, non raw innerHTML.

Le annotazioni Ardesia possono usare gli stessi oggetti ink/note/formula con riferimento fonte/pagina e trasformazione. La AnnotationStorage di PDF.js non è stata studiata né proposta come nuovo ledger di annotazioni. Annotazioni PDF già presenti possono comparire nel raster; le nuove annotazioni Ardesia restano revisionate e separabili, senza riscrivere implicitamente il PDF originale. Canvas da solo non rende selezione testo/ricerca/screen-reader: text layer/accessibilità vanno dichiarati e provati se inclusi, non dedotti dal renderer.

## Legacy: requisiti e codice utile

AndreaMarro/ardesia @ **5cfbdcb055ba3ba136f97fb56e997f06e6cf3605**. Due blob preservati/verificati; lettura selettiva. Nessuna licenza OSS generale dedotta.

- docs/product/ARDESIA_specifiche_integrali_ricostruite_2026-10-28.md:89–98: notebook/lavagna stessi oggetti; PDF/immagini/file, annotazioni ancorate, identità/posizione su save/reopen.
- :419–440: resourceId/revisionId/contextId, hash byte, owner/scope/licenza; layout non muta fonte; 409 preserva bozza,503 non è salvato; upload con intent/compensazione se storage esterno.
- :696 D28 fonte esatta; :723 D55 limiti input/sanificazione/diritti; :749 CORE-006 hash/provenance/scope/revisione; :789–790 LIB-001/002 dedupe/reload e stesso asset.
- packages/engine/lessonos/study/assets.py:17–38 validate_asset: allowlist MIME, dimensioni/decoding immagini, PDF parser strict, cifratura/pagine. Limiti storici 10MiB/16MP immagini e20MiB/20pagine PDF sono un esempio bounded, non default obbligatorio.
- assets.py:63–87 upload: ACL prima, fingerprint comando con hash bytes, intento durevole, insert metadata e compensazione; :95–114 read_original_asset: originale immutabile indipendente da testo/fingerprint PDF, ACL owner/submitted e confronto byte length/hash prima di restituire. **ADAPT** invarianti, **REPLACE** backend nel Core attuale; non importare un secondo store.

Current packages/contracts/src/index.ts:48–75 aveva riferimenti source versionati ma SourceDataSchema solo URL http(s). Estratto/hash in current-source-contract.json è osservazione working tree, non review del candidato finale.

## Ownership, assegnazione e offline

L'owner student mantiene gli stessi diritti personali dell'owner teacher; possesso derivato dall'identità autenticata. Aggiungere il materiale al documento non deve trasferire ownership né aprire il resto della libreria. Endpoint byte/thumbnail/export rivalidano la risorsa e il grant: sapere hash/assetId non è autorizzazione.

Per un documento assegnato, rendere leggibili soltanto gli originali raggiungibili dalla revisione autorizzata; note/ink personali dello studente restano privati fino alla condivisione prevista. L'assegnatario non modifica la fonte del docente. Revoca e cambio account devono impedire applicazione tardiva di byte/render alla nuova sessione. La cache non deve diventare un bypass del grant.

Offline va provato per il perimetro offerto: originale e asset derivati necessari presenti nella copia durevole per account/workspace; niente blob URL serializzato. Upload offline = stato pending recuperabile, non conferma remota. Riapertura non scarica da una URL firmata scaduta né sostituisce il file con 'ultima versione'. Una revoca remota non può essere osservata istantaneamente senza rete: distinguere la policy delle copie owner da eventuali copie assegnate; non affermare più di quanto implementato.

Eliminare una collocazione non deve cancellare bytes ancora referenziati da altre collocazioni o revisioni storiche. Import duplicato può riusare bytes nello scope ammesso ma non deve svelare l'esistenza di un file privato altrui; il riferimento didattico resta distinto dalla deduplicazione fisica.

## REA effettivo e limiti

Node24.22.1, REA CLI6.8.0 verificati; comandi/argv in runs.json. Nessun bundle, PDF, immagine o test donor eseguito.

1. **ev_d62c0534c2194ec88362fcd32479330c63a2dd0968a6783a25bd01a288e964b3** — rea-pdf-lifecycle.json; SHA256 **88ffcdd60679e7ae2d0e39df54bc33acb19f1f75846bb9e638511e7fa13cc74a**. Quattro JS parsati,11053 AST,0 parse failure/integrity contradiction; partial,2690 unknown,non troncato,nessun cap. Tre file inventariati non selezionati. REA dichiara esplicitamente **non analizzato l'inline JS HTML**.
2. **ev_83629c017674ea33f180a3808e93f15ac3145fe3daec7941a9bfae1bd58e3c20** — rea-import-supplement.json; SHA256 **629124a01a14e4f0a9c17f8e9464cbfe7f28e4e4c71d75bc62ff4da3745c7827**. Supplemento con body esatto prevnext.html:24–131, verificato byte per byte e analizzato come mjs, più due TS immagini. Tre file,2794 AST,0 parse failure/integrity contradiction; coverage unknown,630 unknown,non troncato,nessun cap.

Summary separati conservano funzioni/call-site/range e unknown per famiglia; raw e stderr intatti. Dipendenze fuori campione non risolte, causalità/runtime non provati. La slice integra il limite HTML ma non cancella la prima evidence. Source/browser/consumer sono tre prove distinte.

Errori conservati: ricerca legacy iniziale troncata poi estratti limitati; path packages assente nello sparse checkout, corretto con git show; omissione inline JS corretta con artefatto derivato tracciato. Nessuna compatibilità Safari/iPad/Pencil, accessibilità completa o accettazione prodotto dedotta.

## Controprove concrete per il root

1. Import PDF multipagina/immagine → originale hash-identico scaricabile → annota pagina2 → sposta/ridimensiona/zoom/ruota → cambio pagina e riapertura: tratti e fonte corretti.
2. Reload/cold-open offline con copia esplicita: byte disponibili, stessa pagina/revisione, nessuna dipendenza CDN; account B non vede cache di A.
3. Pagina precedente/seguente rapida e cambio documento durante load: nessun render concorrente/canvas errato né risposta tardiva visibile.
4. PDF vuoto/malformed/cifrato, immagine troncata/MIME falso/oversize, quota esaurita e asset mancante: errore onesto, nessun record dichiarato pronto senza originale.
5. Student owner importa/edit; assigned student legge materiale autorizzato e annota privatamente; estraneo/URL indovinato/revoca negano byte/export.
6. Byte alterati rispetto ad hash, incomplete upload, retry idempotente e interruzione riavviabile: niente sostituzione silenziosa o duplicazione.
7. Font non latini/scansione/rotazione/cropBox e DPR alto con budget: eventuali limiti espliciti; preview raster non certifica testo/OCR.

