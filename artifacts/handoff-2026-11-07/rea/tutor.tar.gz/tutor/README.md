# REA — Studio tutor

REA CLI 6.8.0 è stato usato per analisi statica del donor e interazioni reali nel consumer, non soltanto schermate. [Dossier dettagliato](tutor-review.md), manifest Git/SHA256, raw e stderr conservati.

Donor calcom/cal.diy, commit 2eb48eccd8aca8a0c0ffabf28cf92e298b33ecee: cinque sorgenti TypeScript, 3138 nodi AST, zero parse failure/contraddizioni d’integrità, 641 unknown dichiarati. I file selezionati sono MIT e la licenza è conservata. Legacy consultato read-only; nessun codice donor copiato nel prodotto. Nessun test o booking donor eseguito.

Trasferimento concreto: disponibilità rivalidata al commit, intervalli adiacenti ammessi, capienza dei pacchetti, storia dei consuntivi e degli incassi. Cancellazioni locali non attivano email, rimborsi o provider. La disponibilità rapida del donor può indicare available su reserved: non viene usata come autorità.

Due scenari Chrome sul Mac, desktop 1536×1024 e viewport mobile 393×852: apertura agenda, nuova richiesta, salvataggio, riapertura, modifica r2, conti e ritorno agenda. Dati sintetici e mutazioni reali nello stesso HTTP/Core/PostgreSQL. Ogni passo conserva accessibilità, screenshot e osservazioni console/network; il dato di input segreto viene redatto da REA. La precisione temporale/causalità e l’identità del sorgente non sono dedotte dalle catture.

La sorgente è associata separatamente tramite build-info e confronto SHA256 degli asset JS effettivamente osservati/serviti in runtime-source.json. REA non attesta da sola correttezza del backend, qualità scientifica o compatibilità fisica iPad/Pencil/Safari. I test causali e la review indipendente sono nella [consegna](../../verifiche/tutor/README.md).

![Agenda desktop](desktop-back-agenda.png)

[Agenda mobile](mobile-back-agenda.png) · [Quadro economico](desktop-economy.png)

La console conserva un 401 iniziale per scenario: controllo di sessione prima del login in un browser nuovo. Le azioni successive sono completate. Conservato in intermedi/selector-01 anche il primo scenario incompleto: il selettore attendeva una sola riga e ne trovava tre; il selettore è stato precisato senza modificare l’applicazione.
