# Ricerca tutor — calendario, lezioni, ore e registrazioni economiche

Stato: ricerca read-only completata; nessuna implementazione, test del consumer, migrazione o accettazione di prodotto dichiarata. Tutti gli artefatti sono confinati in work/rea-tutor/research/.

## Domanda di prodotto e decisione

Quali comportamenti di disponibilità, cancellazione, spostamento, presenza e annotazione economica conviene adattare nel Core esistente di Ardesia per collegare richieste/studenti, appuntamenti, lezioni, pacchetti/ore e quadro economico senza creare un secondo scheduler o ledger?

Decisione complessiva: ADAPT dei confini e delle invarianti; REPLACE dei gestori del donor con comandi nel Core esistente. Nessuna copia di codice del donor nel prodotto è stata effettuata. REA è prova statica di sorgenti selezionate, non prova del comportamento runtime.

## Provenienza, diritti e prova REA

Legacy: AndreaMarro/ardesia @ 5cfbdcb055ba3ba136f97fb56e997f06e6cf3605. Sette file copiati byte per byte dal checkout di riferimento con git show; Git blob SHA verificato e SHA256 in legacy-manifest.json. Root tree ispezionato: nessun LICENSE alla radice; non si afferma una licenza open-source del legacy. È contesto del progetto autorizzato per la ricerca; non materiale da redistribuire come donor pubblico.

Donor unico: il vecchio URL calcom/cal.com restituisce redirect al repository ID 350360184. La metadata API identifica calcom/cal.diy. Commit immutabile: 2eb48eccd8aca8a0c0ffabf28cf92e298b33ecee, data commit 2026-11-03T21:35:06Z. LICENSE alla radice: MIT, copyright Cal.com, Inc. L'albero ricorsivo completo non è troncato; nessuna licenza più specifica negli antenati dei file selezionati in packages/features e packages/trpc. Altre directory del repository hanno licenze proprie; questa ricerca non ne autorizza il riuso. Se si copiano porzioni sostanziali dei file MIT, preservare notice e licenza. File, URL, Git blob SHA e SHA256 sono in donor-manifest.json; tutti e sette i blob verificati byte per byte.

Tool effettivamente eseguiti: Node 24.22.1, REA CLI 6.8.0, comando analyze-javascript-application, cinque sorgenti TS selezionate, budget 8000 nodi/4000 unknown/30000 ms. Il provider dell'analizzatore nell'evidence è versione 1; non va confuso con la CLI 6.8.0.

Evidence: ev_89513605511383ef9ac9a74b45ad126cbcb0934a05a1ea69bdab84bd6f9cf3d1.
File: rea-cal-lifecycle.json; SHA256 98105170582eb3bc56af2ce7f6aad08e80cedaadf35fb83cf6bdccb3e94b0c8d.
Root artifact SHA256: 937b63108f0b1395a8cbed1951d13279ee2a11396658a8940ecf1eef3bc13d43.
Esito processo 0, cinque file parsati, 3138 nodi AST visitati, zero parse failure, zero integrity contradiction. Il grafo semantico ha copertura partial, non troncata, 641 unknown espliciti (304 ambiguous-target, 195 unknown-value, 129 dynamic-call, 1 dynamic-property, 12 incomplete-module). Il test di merge è inventariato ma non incluso nell'AST. Tutti gli import fuori dal piccolo campione restano non risolti. Nessun codice, test, bootstrap, build o booking del donor è stato eseguito. rea-summary.json conserva funzioni, call-site, range e ID esatti; stderr conserva il progresso reale.

## Sei riferimenti legacy più utili

1. docs/ardesia-v4/specs/02_PERSONE_CORSI_E_GESTIONALE.md:4–35.
   Organization/User/Membership distinti; amministrazione commerciale senza accesso automatico agli elaborati. Template, edizione, sessione, iscrizione, assignment, submission e feedback versionati restano distinti; prezzi fuori dal CoursePack. Le richieste raccolgono materia, microargomento, obiettivo/prova, scadenza e finestre. HOLD con clock DB, lock/capienza/idempotenza; pagamento tardivo senza posto non crea posto. ADAPT. REPLACE i valori storici 4×90 minuti, €49 e max 10 con regole del nuovo incremento, senza inventare un default commerciale.

2. docs/ardesia-v4/specs/05_MCP_CALENDAR_E_ADAPTERS.md:14,22–31.
   Preview con hash/scadenza e commit ancora valido/autorizzato; Ardesia autorevole, calendario esterno fonte free/busy e proiezione. OAuth dell'app distinto dal connettore in chat; mapping provider/account/calendar/event, versione/etag/syncToken. Cambi esterni sono proposte. UTC + zona IANA, ricorrenze ricostruite data per data, passato preservato. ADAPT invarianti; DEFER provider reali.

3. packages/engine/lessonos/study/calendar_time.py:18–45.
   Offset esplicito; roundtrip ZoneInfo rifiuta gap DST e offset incoerenti, l'offset esplicito distingue overlap autunnale. Conflitti half-open: start < old_end and end > old_start; eventi adiacenti ammessi. ADAPT semantica, REPLACE vincoli esatti quattro sessioni e 5400 secondi. L'ID da edizione+ordinale non basta per spostamenti/inserimenti liberi: mantenere identità appuntamento persistente.

4. packages/engine/lessonos/study/calendar.py:63–163,180–229.
   Intent persistente con versione/hash/scadenza, autorizzazione owner, idempotenza, preparazione durevole prima dell'I/O e seconda verifica sotto lock dopo ACK. Reconcile non modifica date canoniche; conflitto -> TEACHER_REVIEW_REQUIRED. ADAPT protocollo delle mutazioni, REPLACE backend legacy nel Core attuale; non importare un secondo store. Capacità dichiarate nel file: Google NOT_CONFIGURED, mock IN_PROCESS_TEST_DOUBLE, push mock, riconciliazione esplicita. Nessuna certificazione Google Calendar.

5. packages/engine/lessonos/study/attendance.py:9–14,39–47,59–92.
   Presenze manuali, non inferite da iscrizione o apprendimento. Ogni record conserva sessionSnapshot, autore, data, revisione e predecessore; correzioni con motivazione e expected revision; un cambio calendario segnala calendarConflict. ADAPT all'atto di consuntivare la lezione. Il sorgente ammette registrazione dopo l'inizio, non dimostra che la lezione sia conclusa: il nuovo consumer deve definire esplicitamente quando e quanti minuti si possono consuntivare.

6. packages/engine/lessonos/study/manual_payments.py:1,21–28,40–103.
   Dichiarazioni manuali append-only con offerta fotografata, interi minor units, riferimento normalizzato e unico nel perimetro owner, correzioni/annullamento che conservano storia; totale dai soli head non annullati nella stessa snapshot di lettura. ADAPT. Il codice dichiara mode:test e MANUAL_DECLARATION_ONLY: non è incasso verificato da provider, fatturazione o prova fiscale. Non promuovere il test ledger a pagamento reale.

Corroborazione letta, non eseguita: packages/engine/tests/study/test_tutor_operations_workflow.py. Descrive gara concorrente sull'ultimo posto, replay idempotente, pagamenti senza variazione dell'ammissione, altri attori esclusi, riconferma per spostamento e riapertura persistente. Non si afferma che questi test siano passati ora.

## Donor: osservazioni e scelte precise

- packages/features/availability/lib/getAggregatedAvailability/date-range-utils/mergeOverlappingDateRanges.ts:3–36, blob 7f2411d33c5611edac2b1a4762108ae507bf2964. Ordina per inizio, unisce solo sovrapposizioni, mantiene massimo end; confronto end > next.start. ADAPT intervalli half-open nel Core. Non copiare la mutazione sort dell'input se le proiezioni ricevono snapshot immutabili. Test sorgente separato copre intervalli contenuti e attraversamento mezzanotte; non eseguito.
- packages/features/bookings/lib/reschedule/isWithinMinimumRescheduleNotice.ts:1–15, blob ed1302887959ff5ab52c38aa223ba507547c98e4. Finestra minima in minuti, confronto strettamente positivo e strettamente minore della soglia. ADAPT policy solo se richiesta; REPLACE new Date() implicito con clock autorevole/iniettabile. Caso esatto soglia, passato e assenza policy vanno definiti: questa funzione restituisce false per prenotazioni già iniziate, non autorizza da sola uno spostamento passato.
- packages/features/bookings/lib/handleCancelBooking.ts:130–181,328–342,357–428,438–519, blob c8f2df2e86f7ec9c10e7664db5bab6cc325c48ee. Blocca doppia cancellazione perché una vecchia booking CANCELLED può già rappresentare uno spostamento dell'evento; controlla blocco cancellazione, motivazione e booking terminata. ADAPT transizioni/guardie. REPLACE orchestration: il file avvia webhook prima della mutazione DB, modifica stato, poi rimborsi/no-show, provider e notifiche con errori spesso registrati separatamente; non è un'operazione atomica globale e il commento 'cancelling first' non vale per tutti gli effetti. In Ardesia nessun rimborso/email/provider implicito dalla cancellazione locale.
- packages/features/bookings/lib/handleSeats/reschedule/owner/moveSeatedBookingToNewTimeSlot.ts:15–41,63–76,111–124, blob 06b1419622ad3e4649d8d2d3a6ab8463873fcfd2. Aggiorna start/end della booking mantenendo riferimenti/payment/attendees, poi reschedule del provider, poi email se abilitate. ADAPT conservazione delle relazioni; REPLACE aggiornamento distruttivo della data senza storia nel comando Ardesia: preservare slot precedente, nuova revisione e motivo, lezione/presenze/consumi già registrati. Il campione non dimostra assenza di audit in altri moduli.
- packages/trpc/server/routers/viewer/slots/isAvailable.handler.ts:19–23,43–65, blob bf2ce030c3903ad32121449cccdf497dae1a1569. Il commento esplicita che è un check veloce senza query booking/calendari. Slot riservati restituiscono status:'available' e realStatus:'reserved' come workaround. REPLACE come autorità di disponibilità: una preview non prenota; commit deve rivalidare occupazioni/capienza e revisione atomiche. Non trasformare un'indicazione UI in diritto o conferma.

Gli ID funzione/call-site REA verificano il campione AST e la posizione delle chiamate; ordine/semantica qui descritti derivano anche dalla lettura diretta. Non si deduce correttezza concorrente o comportamento di import non presenti dal grafo parziale.

## Contratto suggerito al consumer Ardesia

Queste sono raccomandazioni di integrazione, non capacità già provate dal legacy o dal donor.

- Tenere distinti richiesta, relazione tutor-studente, appuntamento, lezione didattica, pacchetto/diritto, presenza/consumo, addebito e dichiarazione di pagamento. Il gruppo organizza persone; la sua capacità non deve essere un contatore client.
- L'appuntamento conserva owner, partecipanti autorizzati, lezione o edizione/revisione, start/end UTC, IANA, stato e revisione. Il tutor può aprire la lezione effettiva dal calendario e lo studente vede solo la propria assegnazione autorizzata. Un legame commerciale non concede accesso a tutto lo storico privato.
- Creazione/spostamento/cancellazione sono comandi idempotenti con expected revision. Verificare identità/scope e grant prima di mutare; bloccare sovrapposizioni tutor e partecipanti secondo policy. Ripetere il controllo al commit, non soltanto durante il rendering del calendario.
- Spostare conserva identità, slot precedente, motivo e collegamento alla lezione. Cancellare conserva lavoro svolto e annotazioni; non consuma automaticamente ore, non cancella elaborati, non rimborsa denaro automaticamente.
- Separare minuti pianificati da minuti svolti. Consumo pacchetto solo con evento esplicito collegato a lezione, studente, presenza, pacchetto e revisione; salvare minuti interi. Correzioni appendono rettifiche; non ricalcolare lo storico dalla durata corrente di calendario. Definire esplicitamente regola per assenza/cancellazione tardiva e rapporto gruppo/minuti per ciascuno.
- Separare prezzo/offerta e compenso maturato per lezioni effettive da cash dichiarato. Salvare importi interi in minor units, valuta e condizione economica esatta; rate o pagamenti parziali sono record distinti. Se si mostrano residui, collegare dichiarazioni all'obbligazione corretta e trattare sovrapagamenti/crediti esplicitamente, non con saldo negativo nascosto.
- Il quadro economico deriva da record autorizzati e snapshot coerente: pianificato, svolto, consumato, maturato, manualmente registrato, residuo. La dashboard non è un secondo ledger. Nessuna efficacia didattica o 'bravura' inferita da presenze, ore o ricavi.

## Verifiche suggerite al parent (non eseguite qui)

1. Richiesta -> studente autorizzato -> appuntamento con lezione esistente -> apertura della lezione dal calendario -> consuntivo -> consumo ore/compenso -> pagamento parziale e quadro aggiornato.
2. Doppio click/retry non duplica appuntamento, consumo o dichiarazione; expected revision stale rifiutata; due richieste sullo stesso slot/ultimo posto non creano doppia conferma.
3. Intervalli adiacenti ammessi, sovrapposti rifiutati; Europe/Rome 2027-03-28 02:30 gap rifiutato, 2027-10-31 02:30 overlap disambiguato dall'offset; mezzanotte e timezone diversa.
4. Spostamento dopo presenza registrata non riscrive snapshot/consumi; annullamento conserva lezione e pagamenti; correzione manuale ha autore/motivo/predecessore; void escluso dai totali.
5. Altro tutor e studente estraneo non leggono o mutano registri; grant revocato impedisce accesso didattico successivo; appartenenza commerciale non apre elaborati privati.
6. Riapertura persistente mantiene collegamenti/revisioni e stessi totali; disponibilità preview diventata obsoleta non viene confermata.

Limiti: nessuna autenticazione/account, UI runtime donor, booking, messaggio, pagamento, OAuth, servizio, installazione o scheduler. Nessun test del legacy o donor eseguito. Il parent deve testare il consumer reale; la prova REA non è acceptance. Errori conservati: glob legacy assente nella cartella Next, redirect repository risolto, primo inventory scratch assente. Una prima estrazione troppo ampia del grafo è stata troncata nell'output terminale; rea-summary.json è stato poi prodotto con campi selettivi senza perdita del file raw.

