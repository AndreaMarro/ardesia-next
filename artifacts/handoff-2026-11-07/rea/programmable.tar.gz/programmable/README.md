# REA — Creator programmabile

REA 6.8.0 è stato usato via CLI con Node 24.22.1 per leggere implementazioni e osservare interazioni. [Fonti, decisioni e attribuzioni](../../ardesia-next/docs/sources/programmable-creator-2026-11-07.md). Questo dossier prosegue [Excalidraw/tldraw](../redesign/README.md), [H5P](../corsi/README.md) e l’analisi precedente della lavagna.

## Donor e trasferimento

| Evidenza | Osservazione utile | Limite |
|---|---|---|
| [Sandpack statico](sandpack-static-evidence.json), `ev_9671f0b6…` | Quattro file TypeScript, 2651 nodi AST; handshake, compilazione, errori, refresh e destroy. | Semantica parziale, due file inventariati fuori scope, dipendenze/runtime non coperti. |
| [Sandpack interattivo v2](sandpack-edit-v2-evidence.json), `ev_7d3e8366…` | Modifica → anteprima → errore sintattico → riparazione → refresh. Dieci azioni e avvio completati. | Record **incomplete/events**: richieste ancora aperte al termine; non prova di completezza della rete. |
| [Confine Next](quickjs-host-analysis.json), `ev_631be3b7…` | AST di engine e Worker: dove passano input, risultato e validazione. | Cap 3000, 11 file inventariati fuori scope; non audit QuickJS/WASM. |

Sandpack: commit `7d60a4334980eef304d53b1c3df371ed6dbcf491`, client 2.19.8, [Apache-2.0](SANDPACK-LICENSE.txt). [Ricerca indipendente e blob Git verificati](sandpack-review.json). Il sito pubblico non è attribuito allo stesso commit. Nessun login, paywall o restrizione aggirati; nessun codice, branding o contenuto donor copiato in Ardesia. La licenza del codice non attribuisce diritti automatici su servizi e media.

**Adattato:** codice e anteprima nello stesso ambiente, stati espliciti, errore recuperabile e ricostruzione. **Sostituito:** bundler esterno e privilegi del frame con un motore isolato, consenso temporaneo e risultati passivi. Il channelId di Sandpack è instradamento, non autenticazione; rimuovere listener non dimostra l’arresto del codice. Non si dichiara una vulnerabilità sfruttabile del servizio pubblico.

Il primo [scenario fallito](sandpack-edit-evidence.json) e il suo [input](sandpack-edit.json), gli stderr e le analisi parziali sono conservati. Non sono prove positive.

## Consumer Ardesia finale

Sorgente `ab181bddd390c15fe74a1a09f29d0dc3c3208e4936d540943779a5cbdc576e8a`, [associazione build-info esterna](release-runtime-source.json). REA dichiara source identity non disponibile: il record originale non è riscritto. [Dieci asset osservati](release-asset-hashes.json) sono stati riletti subito dopo e confrontati con la dist immutata; non si spaccia il refetch per byte della risposta originale.

| Cattura | Ambiente | Esito |
|---|---|---|
| [Desktop](release-desktop-evidence.json), `ev_8a4c0eb1…` | Chrome 156 su Mac, 1536×1024 | 26 azioni più avvio, tutte completate; cattura complete. |
| [Mobile](release-mobile-evidence.json), `ev_47450b76…` | Stesso browser, viewport 412×915 | 26 azioni più avvio, tutte completate; cattura complete. |

Percorso: login sintetico → libreria → oggetto salvato → modifica struttura → avvio → stato precedente visibile → nuovo nome/versione → consenso nuovo → aggiunta idea → salvataggio → taccuino → riavvio con stato conservato → stop. Nessun mock sostituisce Core o PostgreSQL. Processi REA posseduti terminati. Le catture abf0 restano in [intermedi](intermedi/runtime-source.json), senza promozione alla fonte finale.

Console: un 401 iniziale su `/api/m3` prima del login per ciascuna sessione, coerente con l’accesso anonimo. Nessun altro errore console nei record finali. Request/response body e valori header non acquisiti; password sintetica referenziata tramite meccanismo secret REA. Service Worker bloccati dalla configurazione REA: questa non è una prova dell’offline, coperto separatamente dagli E2E.

![Creator desktop reale](release-desktop-idea-visible.png)

[Anteprima mobile](release-mobile-idea-visible.png) · [Taccuino mobile](release-mobile-reopened-state.png) · [Verifica visiva](../../design/programmable-verifica.md).

Non dimostrati: hardware iPad/Apple Pencil, Safari, app native, latenza real time, carichi elevati, correttezza scientifica dei programmi, audit completo del motore o universalità totale. Un record completo attesta il suo scenario e la sua configurazione, non tutto il prodotto.
