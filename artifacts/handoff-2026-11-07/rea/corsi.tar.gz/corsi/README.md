# REA — corsi e studio

REA6.8.0 CLI è stato usato su H5P Interactive Book e sul consumer Ardesia. [Fonti e decisioni implementative](../../ardesia-next/docs/sources/courses-2026-11-07.md). L’analisi prosegue il [lavoro su Excalidraw/tldraw e Creator](../redesign/README.md); non lo sostituisce.

## Domanda e diritti

Come mantenere navigazione, attività, risposta, aiuto e ripresa distinti in un percorso interattivo? Target pubblico: `https://h5p.org/h5p/embed/439596`, dal [tipo Interactive Book](https://h5p.org/content-types/interactive-book), senza login o aggiramenti. Bundle esposto dal browser: H5P.InteractiveBook1.11.11,93721byte, SHA-256 `34011742a5f16d7eb2d54f4f1c7e043598e53966866434e93177911373e85f23`.

[MIT Joubel2017](shipped/LICENSE) e [library.json](shipped/library.json) verificati upstream alla SHA `4e647f3e9c57cb161574d12ec7dddb44eabfc225`. Due commit dichiarano la stessa versione: nessun rebuild byte-per-byte, attribuzione univoca non provata. La licenza del componente non copre automaticamente demo, media e dipendenze. Il bundle è conservato come reperto; nessun codice, testo o immagine donor è copiato in Ardesia.

## Evidenze donor

| Record | Cosa prova | Limiti |
|---|---|---|
| [Statico](h5p-static-evidence.json), `ev_11778b15…` | AST/grafo del bundle; navigazione con frammenti, serializzazione `getCurrentState`, ripristino `previousState`, distinzione punteggio/attività. | Grafi parziali, chiamate dinamiche irrisolte, bootstrap non eseguito. |
| [Interazioni v2](h5p-interactions-v2-evidence.json), `ev_6243443e…` | Read, risposta con feedback, Next, riapertura anonima. |774eventi conservati/163omessi; Previous/Summary troppo ravvicinati, risultato non raggiunto. |
| [Interazioni v3](h5p-interactions-v3-evidence.json), `ev_c088fd11…` | Risposta conservata con Previous; Summary distingue1/22punti,0/4pagine e1/8interazioni; reload anonimo senza risposta. |734eventi/0omessi, completezza della configurazione soltanto. Storage/autenticazione/persistenza del contenitore non osservati. |
| [Review indipendente](review/independent-review.json) | Confronto codice/catture/diritti, limiti e riesame v3. | Contesto AI separato, non review scientifica umana. |

![Riepilogo H5P osservato](h5p-summary-settled.png)

Le azioni della v3 aspettano le transizioni. Il codice ignora i cambi capitolo durante animazione250ms: coerente con il fallimento v2, non causalità misurata. Nessun click Submit Report; la stringa AX di conferma è sempre montata e non è ricevuta di invio. I POST osservati sono analytics. La riapertura anonima non descrive H5P autenticato.

Conservati anche target iniziali errati (forum, embed441940 non Book), errore di schema capture e403 del download diretto. Non sono donor validi. Il bundle proviene dai body pubblici esposti dal browserREA, decodificati e verificati; il provider può rifetchare i byte, quindi non si certifica il wire originale. Tutti i file hanno manifest di consegna.

## Trasferimento originale

**ADAPT:** indice leggibile, unità/fase corrente e ripresa separati dalle risposte. **REPLACE:** progressi basati su evidenze di tentativi/aiuti, senza inventare competenza dai click. **DEFER:** H5P runtime, SCORM/xAPI, hosting o pubblicazione esterni. Un solo Core autorevole e un solo formato versionato; nessun porting del renderer H5P.

## Consumer Ardesia

Le catture della prima candidata sono legate a [runtime-source.json](runtime-source.json). Desktop1536×1024, mobile412×915, Chrome156; gli account e testi sono sintetici locali.

- [Creazione desktop](ardesia-desktop-evidence.json), `ev_33144b8e…`: creazione, salvataggio, edizione, self-study, aiuto con risposta aperta, salvataggio e cambio fase riusciti. La navigazione finale allo stesso URL non ha ricaricato il documento: attesa della libreria fallita, record incompleto; non è prova di ripresa.
- [Ripresa desktop in nuova sessione](ardesia-desktop-resume-evidence.json), `ev_83cf1c17…`: nuova istanza browser, login, libreria e stessa attività/risposta conservata;7step completi.
- [Flusso mobile](ardesia-mobile-evidence.json), `ev_a51cc653…`:24step completi, dalla creazione alla riapertura. La nuova query dichiarata provoca una navigazione effettiva. Nessun test hardware iPad/Pencil.

Gli scenari, record raw, screenshot e limiti restano separati dai report E2E/Core/PostgreSQL/MCP. Una schermata o un record completo non certifica l’intero prodotto. Eventuali catture di rilascio successive conservano un’associazione sorgente propria.

## Rilettura della candidata di consegna

Sorgente `081188333e269835da397aeed2959ce7a80f3d72552f1893c167f19f895f5458`, associazione esterna in [release-runtime-source.json](release-runtime-source.json). Due nuove istanze browser, login, libreria, ripresa della fase attività e risposta precedente visibile:8step completi ciascuna. [Desktop](release-desktop-evidence.json) `ev_a780c4a2…`; [mobile](release-mobile-evidence.json) `ev_de3f7659…`. Entrambe terminano il processo posseduto. Non riattribuiscono alla nuova sorgente le catture dd3 precedenti.

![Studio desktop di consegna](release-desktop.png)

[Studio mobile osservato](release-mobile.png). Ispezione visiva di tipografia, spazi, indice, domanda, strumenti e responsive: nessun mock usato al posto del consumer. Il mobile richiede scorrimento verticale, con indice sopra il contenuto; la prova non è hardware Apple Pencil.
