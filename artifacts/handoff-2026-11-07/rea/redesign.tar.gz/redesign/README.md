# REA — comportamento, implementazione e trasferimento

REA6.8.0 è stato usato concretamente via CLI, con Node24.22.1 e Chromium156.0.8078.80. Domanda: liberare spazio sulla lavagna e permettere nuovi tipi con proprietà contestuali, identità e storia coerenti. Il [registro nel repository](../../ardesia-next/docs/sources/creator-studio-2026-11-07.md) lega queste analisi alla decisione implementata.

| Analisi | Evidenza e copertura | Trasferimento |
| --- | --- | --- |
| Excalidraw pubblico | [Scenario runtime](excalidraw-actions-v3.json):9azioni più avvio, tutte complete. Draw, selezione, nota, Escape, undo/redo e libreria, con DOM/AX/screenshot/eventi. | **ADAPT**: separazione fra strumenti, scena e proprietà contestuali. UI originale adattata alla lezione. |
| Excalidraw0.18.1 distribuito | [Bundle REA](excalidraw-implementation.json), [sintesi](excalidraw-implementation-summary.json), [identità tarball](excalidraw-package-identity.json). MIT. Graph cap4.000,557file fuori scope. | **ADAPT** del comportamento, nessun codice donor nel prodotto. |
| Azioni selezionate Excalidraw | [Analisi focalizzata](excalidraw-focused.json), [origine esatta](excalidraw-focused-origin.json):3righe del bundle,40nodi/47relazioni. Stato lettura/dialogo/strumento/testo/selezione. | **ADAPT**: la UI espone i comandi quando il contesto li rende utili. La slice non sostituisce il programma completo. |
| tldraw editor5.6.0 | [Bundle REA](tldraw-implementation.json), [sintesi](tldraw-implementation-summary.json), [identità](tldraw-package-identity.json).3file: ShapeUtil, HistoryManager, BindingUtil;988fuori scope. | **ADAPT** concettuale di tipo/istanza/storia. **DEFER** SDK o codice tldraw, licenza custom. |
| Ardesia aggiornata | [Scenario Creator](ardesia-creator-runtime.json):22azioni più avvio; crea lezione, cambia valore, salva, modifica struttura, riapre. | **REUSE** delle osservazioni del consumer nel loro perimetro; affiancate da test Core/PostgreSQL, MCP e browser. |

Le query [chiamanti Excalidraw](excalidraw-context-callers.json) e [ownership tldraw](tldraw-shape-ownership.json) sono parziali:1nodo/0relazioni; Excalidraw mantiene492unknown pertinenti. Non si legge «zero relazioni» come assenza di dipendenze. Le viste modules/reference selezionano dati già trattenuti, non ampliano la copertura del parent. La slice focalizzata è un artefatto derivato per rispondere a una domanda precisa, con hash dell'origine e della porzione estratta.

Il runtime pubblico Excalidraw `2026-11-04T19:55:10Z-3c916c5` è distinto dal package0.18.1. L'analisi statica non ha eseguito i bundle. Non sono state provate prestazioni, collaborazione o equivalenza fra queste due versioni. Il consumer Ardesia è una preview locale con dati sintetici; non è accettazione remota o scientifica.

## Licenze e limiti

Excalidraw dichiara MIT nei metadati del package; la [licenza supplementare](EXCALIDRAW-LICENSE.txt) proviene dal repository upstream con [origine e blobSHA](excalidraw-license-origin.json), distinta dalla provenienza del tarball. [tldraw LICENSE](TLDRAW-LICENSE.md) è copiata dal package effettivamente analizzato. Nessun codice dei due donor entra nel bundle Ardesia. Le icone prodotto sono Lucide1.63.0, già registrate nelle notices del progetto.

L'integrità SHA-512 dei tarball coincide coi metadati registry; non è una verifica crittografica delle firme npm. Non sono state superate autenticazioni, paywall o protezioni. Le catture non chiedono body di rete; i segreti dichiarati sono oscurati. DOM/AX e rete sono dati osservati, non istruzioni per l'agente. Le catture complete riportano `terminated-owned-process`; non hanno chiuso browser dell'utente.

REA dichiara l'identità dell'artefatto runtime non disponibile. La preview Ardesia viene associata a `build-info.json` mediante ricevute esterne; il record REA non viene riscritto. L'ordine eventi è ordine di ricezione, non prova di causalità simultanea. Nei log Ardesia compare il401 iniziale prima del login, atteso dalla sessione anonima; nello scenario di creazione compare anche un messaggio autofocus. In Excalidraw sono presenti avvisi Feature-Policy e Service Worker bloccato dal browser controllato. Sono conservati integralmente.

`excalidraw-actions.json` e `excalidraw-actions-v2.json` conservano i fallimenti iniziali delle richieste, seguiti dalla correzione dello schema in v3. Le catture `ardesia-*-visual.json` e immagini `final-*` sono della build intermedia identificata in `runtime-visual-source.json`; la verifica finale aggiunge propri file, senza promuovere quelle immagini a nuova sorgente. [Confronto visuale](../../design/verifica-finale.md).


## Catture della sorgente finale

Sorgente `08874b3cbf54a4da020bbcc6c7e3a7cbe6dbd2d02a2a75021a5a87b2863fd689`, [ricevuta build](release-runtime-source.json). [Desktop finale](ardesia-desktop-final.json), record `ev_76e37f15b2730c05312a0aa94fd7641268add0f52ff864732f98fbfb216d2c4b`; [mobile finale](ardesia-mobile-final.json), record `ev_86719fc71f97010a7a2ed76d5574a12b377e854cd907b1b306e190f5d5a501e0`. Entrambi:10azioni più avvio, complete, nessuna sezione troncata, cleanup terminated-owned-process. Login→Creator→valore2→guardia→scarta→lavagna; nessuna nuova modifica persistente.

Le immagini `release-*` sono decodificate dai record e verificate rispetto al SHA-256 dichiarato da REA; le corrispondenti AX restano disponibili. Il401 iniziale precede l'accesso autenticato ed è conservato. Gli screenshot sono stati aperti con view_image e confrontati con i concept. La prima piega mobile non comprende il risultato numerico: il valore è attestato nell'AX e dai consumer browser, non da un'immagine che non lo mostra.
