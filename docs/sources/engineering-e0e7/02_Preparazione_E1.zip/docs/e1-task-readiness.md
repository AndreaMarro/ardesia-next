# E1 — Controllo preventivo READY (proposta isolata)

## Stato e confine

Preparazione locale del piano di ingegnerizzazione del 2 novembre 2026, issue #39.
**Non integrata, non adottata, non una nuova autorità di esecuzione.**

La PR #38 ha già riconciliato lo scope M4. Questo lavoro non ripete quell'intake e
non modifica il consumer Poiseuille, il cursore, la coda, gli scheduler o i gate.

Il modulo esporta `validateTaskReadiness(task, observedContext)` e
`readinessDigest(value)`. Non legge file, non avvia processi, non effettua rete,
non seleziona modelli e non modifica argomenti o stato persistente.
Un `ready: true` è una diagnosi di coerenza dei prerequisiti dichiarati, NON un
claim, un permesso di scrittura, una review, una prova remota o un'accettazione.

## Perché un helper separato

Il checker vigente verifica forma/policy della coda e, per il freeze, legge la
baseline M3 attraverso il motore di stato. Qui serve una funzione pura per
confrontare requisiti del consumer e osservazioni correnti, senza legare una
diagnosi di task a filesystem, database o valutazione delle milestone. Il runner
esistente deve chiamarla; non si aggiunge un esecutore, un archivio o un motore.

## Contratto proposto

`task` è l'intera riga invariata della coda adottata, non una richiesta modificata
in memoria dall'autore. La coda va prima validata dal checker esistente.

Il contesto contiene esattamente:

- `canonicalTask`: la stessa riga riletta dalla sorgente canonica; `null` per task
  assente. Un autore non può sostituirla con la propria copia per auto-autorizzarsi.
- `procedureRef`, `sourceSha`, `policyDigest`: identità immutabili della procedura,
  del candidato e della policy. Procedura e runtime possono essere diversi.
- `requirements`: requisiti del consumer approvati e versionati; non dedotti
  soltanto dal titolo del ticket e non una lista arbitraria fornita dal worker.
- `dependencies` e `blockers`: liste `{id,status}` lette dalla fonte autorevole.
- `now`: istante UTC in formato `Date.toISOString()`, fornito dal runner.
- `observed`: osservazioni realmente acquisite dall'adapter autorizzato.

`requirements` contiene `taskId`, `procedureRef`, `consumer`, `risk` (R0/R1/R2),
`requiredPaths` (file esatti), `requiredCapabilities` (identificatori non segreti),
`requiredEvidence` (controlli da eseguire, NON loro esiti), `executionProfile`
(`id`,`effort`), `rollback` e `maxObservationAgeMs` (intero positivo).
Il massimo di età è una scelta della policy approvata, non della singola run.
I cinque minuti usati nei test sono una fixture, non una policy già adottata.

Il runner deve ricavare `requirements.procedureRef` dalla lettura immutabile:
**non scrivere nel sorgente la SHA futura di quel medesimo sorgente.**
`readinessDigest` è un digest diagnostico del contenuto JSON, distinto dal
`sourceDigest` autorevole e senza alterare i suoi algoritmi o gate.

`observed` contiene `taskId`, `procedureRef`, `sourceSha`, `policyDigest`,
`taskDigest`, `requirementsDigest`, `observedAt` e:

- `capabilities`: lista `{id,status}`, status available/unavailable/unknown;
- `executionProfile`: `{id,effort,status}`, status verified/unavailable/unknown.

Il risultato contiene `ready`, `blockers`, `missingPaths`, `requiredEvidence`,
`binding`, `acceptanceEvidence:false` e `authorizationGranted:false`.
Non conserva password, cookie, URL di database o log grezzi.

## Limiti che il consumer deve rispettare

I valori del contesto non si autenticano da soli: un JSON falsificato ma coerente
non prova accessi, modello o disponibilità di servizi. Il fetch della sorgente,
la validazione della policy e le osservazioni effettive appartengono al runner.
La funzione non può dimostrare che la lista dei file necessari sia esaustiva;
essa deve derivare dall'analisi del consumer e dalla review del contratto.

Il confronto di percorsi è lessicale, con la medesima semantica di prefissi
letterali del coordinamento corrente. Non è una sandbox filesystem: eventuali
symlink, dirty state, base Git, diff finale e ACL vanno controllati dal punto di
scrittura. I claim/CAS e le protezioni remote restano obbligatori; nessun tempo
scaduto trasferisce proprietà. Rileggere le identità prima della mutazione.

## Integrazione ancora necessaria per completare E1

1. L'integratore acquisisce E1 nella coda tramite un intake esplicito e riesaminato.
   Non usa lo scope M4 né OPS-004 per ampliare la propria autorità.
2. Estende in modo esplicito il contratto della coda per i requisiti READY,
   oppure li deriva da un contratto già approvato e immutabile. L'attuale schema
   strict rifiuta campi nuovi: non aggirarlo e non fingere che questa patch lo
   abbia già aggiornato. Il taskDigest include la riga canonica completa.
3. Collega la funzione nel percorso esistente PRIMA dell'avvio implementativo e
   prima delle scritture, senza un secondo runner. Dati mancanti producono un
   blocco circoscritto; la sola lettura preparatoria non diventa vietata.
4. Aggiunge test del wiring: la vecchia UI-scope omission ferma davvero l'avvio;
   il caso valido continua attraverso gli stessi claim/CAS. Nessun grant deriva
   dal solo `ready`, nessun override `force`, nessun reset di credenziali.
5. Esegue test/Verify della nuova head nella toolchain Node24 del progetto,
   review non autrice, adozione e un incarico reale. Solo allora E1 è completato.

Le prove locali del puro validator NON sostituiscono questi cinque passaggi.

## Verifiche locali riproducibili

```
node --check tools/task-preflight.mjs
node --test tools/task-preflight.test.mjs
```

Il primo test riproduce in dati sintetici lo scope M4 precedente a #38; il secondo
ha lo scope esteso. Gli altri controllano sorgenti obsolete, prerequisiti, profili,
input malformati e non mutazione. Non sono i 291/312 test della repository.

Ambiente di questa preparazione: Node22.16.0, fuori dal motore Node24 richiesto
nel progetto. Nessun test browser/PostgreSQL, CI completa o review indipendente
è stato eseguito qui. I log RED e GREEN sono forniti nel pacchetto di consegna.

## Rollback

Finché non integrata, nessun rollback remoto serve. Dopo un'eventuale adozione,
revert dei soli helper/wiring con nuova revisione riesaminata; nessun downgrade
dati, cancellazione di ricevute o riattivazione dei vecchi scheduler.
