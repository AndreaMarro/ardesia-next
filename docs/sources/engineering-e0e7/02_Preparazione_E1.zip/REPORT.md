# Ardesia Next — ricevuta di esecuzione iniziale del piano

Data: 2 novembre 2026. Stato: **mandato registrato; E1 preparato in isolamento, NON adottato**.

## Mandato

Il piano allegato E0–E7 è la base del lavoro. Non è stato riscritto né sostituito.
Fonte originale: `PLAN_RECEIVED.md`, SHA256
`e51f15602bea159a16edf999561d39a3b9fbf1cdfe898ebd41cad5c0918503b1`.

## Operazioni remote realmente eseguite

- Riletti PR38 e cursore109 alla ref immutabile
  `d39138cfa11b998b6bc73a9b3cea8d4f3298db5a`.
- Confermata procedura adottata `413de5bba02537cc090c91db58887b49de08eae4`;
  il perimetro M4 è pronto. Non è accettazione del consumer Poiseuille o del piano.
- Creata issue39 come input di mandato per l'unico integratore:
  https://github.com/AndreaMarro/ardesia-next/issues/39
- Pubblicato e riletto il collegamento sulla PR38:
  https://github.com/AndreaMarro/ardesia-next/pull/38#issuecomment-6586654791
- Pubblicato lo stato della preparazione e i limiti:
  https://github.com/AndreaMarro/ardesia-next/issues/39#issuecomment-6586647798

L'esistenza dei commenti non prova che il worker li abbia già letti o adottati.
Nessuna scrittura a sorgenti remoti, main, staging, coda, cursore, credenziali,
modelli, automazioni o gate. Nessuna CI rilanciata, nessun merge/deploy.

## Preparazione tecnica

Nuovi file proposti: `tools/task-preflight.mjs`, `tools/task-preflight.test.mjs`,
`docs/e1-task-readiness.md`. Funzione pura per controllare prerequisiti dichiarati,
scope completo del consumer, identità della sorgente/procedura/policy, dipendenze,
capability/fixture e profilo osservato. Nessun accesso remoto o grant di scrittura.

I requisiti devono provenire dal contratto canonico approvato. Un JSON coerente
non autentica modello, permessi o accessi. La lista dei file deve essere riesaminata;
la funzione non può inferire automaticamente che sia esaustiva. I claim e il
controllo al punto di pubblicazione restano separati e obbligatori.

## Prove effettive e relativi limiti

| Verifica | Esito | Perimetro |
|---|---|---|
| RED iniziale | 31 falliti / 1 passato | Stub di preparazione locale, non test della repository |
| Syntax check | PASS | Solo il nuovo helper |
| Test finali | 32 PASS, 0 fail, 0 skip | Fixture sintetiche del nuovo helper |
| Mutazioni intenzionali | 5/5 rilevate | Scope, policy, dipendenza, effort, freschezza |
| Diff whitespace | PASS | File locali proposti |
| Pipeline repository su Node24 | NOT_RUN | Non disponibile in questa sessione |
| Browser/PostgreSQL/preview | NOT_RUN | Nessuna attribuzione dalle prove PR37/38 |
| Review non autrice | PENDING | Non simulata dalla review interna |
| Wiring/adozione/incarico reale | PENDING | E1 non è completato |

Ambiente locale: Node22.16.0, fuori dalla versione Node24 richiesta dal progetto.
Non c'è un checkout integrale del repository: il pacchetto è una proposta di soli
file nuovi. Il clone pubblico non è riuscito per DNS e Desktop Commander non ha
rilevato dispositivi connessi. Il rapporto locale Mac indicato dal titolare non è
stato letto; sono state lette le corrispondenti fonti GitHub.

Il tentativo di pubblicare i sorgenti come commento GitHub è stato bloccato dai
controlli di sicurezza della piattaforma. Non è stato aggirato con altri canali.
I sorgenti sono quindi nella consegna locale, non ricevuti dal runner remoto.

## Stato degli incrementi

E0: la parte scope è già stata risolta dalla PR38; consumer e convergenza rimangono
separati. E1: helper e test preparati, ma mancano intake/schema, wiring nel runner,
verifica completa conforme, review indipendente, adozione e una prova reale.
E2–E6: non applicati. E7: nessuna nuova unità didattica realizzata in questa attività.
Le nuove ricorrenze Pro/Codex non sono state attivate e OpenCode non è stato installato.

## Prossimo passaggio

L'integratore acquisisce il mandato della issue39 nella coda esistente senza
interrompere M4, definisce il contratto canonico E1 e collega il controllo prima
dell'avvio implementativo. La nuova integrazione richiede le proprie prove.
Non si amplia scope tramite OPS-004 e non si attribuiscono PASS storici alla patch.

## Pacchetto

Sono inclusi i sorgenti, i test, la nota d'integrazione, il piano originale,
i log di verifica, il manifesto SHA256 e una patch dei tre file nuovi.
I risultati restano riproducibili; non sono una certificazione della repository.
